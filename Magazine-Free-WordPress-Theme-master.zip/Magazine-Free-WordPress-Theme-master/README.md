Magazine
===========================

Best free responsive WordPress Theme for blog and news website
-------------------------

* _Template DEMO: [VIEW DEMO](http://demo.gavick.com/wordpress/magazine/)_
* _Template files: [DOWNLOAD](http://www.gavick.com/download/download-wordpress-themes/magazine_wp.html)_