<?php

// disable direct access to the file	
defined('GAVERN_WP') or die('Access denied');	

/**
 *
 * GavernWP admin panel & page features
 *
 * Functions used to create GavernWP-specific functions 
 *
 **/

/**
*
* Code to inlcude necessary plugins
*
**/

// include TGM Plugin Activation class
require_once(gavern_file('gavern/classes/class-tgm-plugin-activation.php'));

/**
 * Register the required plugins for this theme.
 *
 * The variable passed to tgmpa_register_plugins() should be an array of plugin
 * arrays.
 *
 * This function is hooked into tgmpa_init, which is fired within the
 * TGM_Plugin_Activation class constructor.
 */
function gavern_register_required_plugins() {
    /**
     * Array of plugin arrays. Required keys are name and slug.
     * 
     */
     $plugins = array(
 
         // Plugins pre-packaged with a theme.
         array(
             'name'               => 'GK News Show Pro',
             'slug'               => 'gk-nsp',
             'source'             => 'https://www.gavick.com/upd/gk-nsp.zip', 
             'required'           => true,              
             'version'            => ''
         ),

         array(
             'name'               => 'GK Tabs',
             'slug'               => 'gk-tabs',
             'source'             => 'https://www.gavick.com/upd/gk-tabs.zip', 
             'required'           => true,              
             'version'            => ''
         )
 
     );
     
     /**
      * Array of configuration settings. 
      */
     $config = array(
         'id'           => 'tgmpa',
         'menu'         => 'tgmpa-install-plugins',
         'has_notices'  => true,
         'dismissable'  => true,                    
         'is_automatic' => false,
         'strings'      => array(
            'menu_title'                      => __( 'Install Plugins', GKTPLNAME ),
            'page_title'                      => __( 'Install Required Plugins', GKTPLNAME ),
            'installing'                      => __( 'Installing Plugin: %s', GKTPLNAME ), 
            'oops'                            => __( 'Something went wrong with the plugin API.', GKTPLNAME ),
            'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', GKTPLNAME ), 
            'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', GKTPLNAME ),
            'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', GKTPLNAME ),
            'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', GKTPLNAME ),
            'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', GKTPLNAME ),
            'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', GKTPLNAME ),
            'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', GKTPLNAME ),
            'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', GKTPLNAME ),
            'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', GKTPLNAME ),
            'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', GKTPLNAME ),
            'return'                          => __( 'Return to Required Plugins Installer', GKTPLNAME ),
            'plugin_activated'                => __( 'Plugin activated successfully.', GKTPLNAME ),
            'complete'                        => __( 'All plugins installed and activated successfully. %s', GKTPLNAME ),
            'nag_type'                        => 'updated'
         )
     );
 
     tgmpa( $plugins, $config );
}

add_action( 'tgmpa_register', 'gavern_register_required_plugins' );

/**
 *
 * Code to create shortcodes button
 *
 **/

function add_gavern_shortcode_button() {
    global $typenow;
    // check if user can edit posts or pages
    if ( !current_user_can('edit_posts') && !current_user_can('edit_pages') ) {
   		return;
    }
    // only on Post Type: post and page
    if( ! in_array( $typenow, array( 'post', 'page' ) ) )
        return ;
	// check if the user enabled rich editing mode
	if ( get_user_option('rich_editing') == 'true') {
		add_filter("mce_external_plugins", "add_gavern_tinymce_plugin");
		add_filter('mce_buttons', 'register_gavern_shortcode_button');
	}
}
// 
function register_gavern_shortcode_button($buttons) {
   // add the shortcode button to the list
   array_push($buttons, "gavern_shortcode_button");
   return $buttons;
}
// Load the plugin script
function add_gavern_tinymce_plugin($plugin_array) {
	// add the shortcode button script to the list
   	$plugin_array['gavern_shortcode_button'] = gavern_file_uri('js/back-end/gavern.shortcode.button.js');
   	return $plugin_array;
}

/**
 *
 * Code to create custom metaboxes with post additional features (description, keywords, title params)
 *
 **/

function add_gavern_metaboxes() {
	global $tpl;
	// post description custom meta box
	if(get_option($tpl->name . '_seo_use_gk_seo_settings') == 'Y' && get_option($tpl->name . '_seo_post_desc') == 'custom') {
		add_meta_box( 'gavern-post-desc', __('Post keywords and description', GKTPLNAME), 'gavern_post_seo_callback', 'post', 'normal', 'high' );
		add_meta_box( 'gavern-post-desc', __('Page keywords and description', GKTPLNAME), 'gavern_post_seo_callback', 'page', 'normal', 'high' );
	}
	// post title
	add_meta_box( 'gavern-post-params', __('Post additional params', GKTPLNAME), 'gavern_post_params_callback', 'post', 'side', 'default' );
	add_meta_box( 'gavern-post-params', __('Page additional params', GKTPLNAME), 'gavern_post_params_callback', 'page', 'side', 'default' );
}

function gavern_post_seo_callback($post) { 
	$values = get_post_custom( $post->ID );  
	$value_desc = isset( $values['gavern-post-desc'] ) ? esc_attr( $values['gavern-post-desc'][0] ) : '';    
	$value_keywords = isset( $values['gavern-post-keywords'] ) ? esc_attr( $values['gavern-post-keywords'][0] ) : ''; 
	// nonce 
	wp_nonce_field( 'gavern-post-seo-nonce', 'gavern_meta_box_seo_nonce' ); 
    // output
    echo '<label for="gavern-post-desc-value">'.__('Description:', GKTPLNAME).'</label>';
    echo '<textarea name="gavern-post-desc-value" id="gavern-post-desc-value" rows="5" style="width:100%;">'.$value_desc.'</textarea>'; 
    // output
    echo '<label for="gavern-post-desc-value">'.__('Keywords:', GKTPLNAME).'</label>';
    echo '<textarea name="gavern-post-keywords-value" id="gavern-post-keywords-value" rows="5" style="width:100%;">'.$value_keywords.'</textarea>';    
} 

function gavern_post_params_callback($post) { 
	$values = get_post_custom( $post->ID );  
	$value_title = isset( $values['gavern-post-params-title'] ) ? esc_attr( $values['gavern-post-params-title'][0] ) : 'Y';
	$value_image = isset( $values['gavern-post-params-image'] ) ? esc_attr( $values['gavern-post-params-image'][0] ) : 'Y'; 
	$value_templates = isset( $values['gavern-post-params-templates'] ) ? $values['gavern-post-params-templates'][0] : false; 
	// if the data are JSON
	if($value_templates) {
		$value_templates = unserialize(unserialize($value_templates));
		$value_contact = $value_templates['contact'];
		
		if($value_contact != '' && count($value_contact) > 0) {
			$value_contact = explode(',', $value_contact); // [0] - name, [1] - e-mail, [2] - send copy   
		}
	}
	// parse the aside values
	$value_aside = isset( $values['gavern-post-params-aside'] ) ? $values['gavern-post-params-aside'][0] : false;
	if($value_aside) {
		$value_aside = unserialize(unserialize($value_aside));
	}
	// nonce 
	wp_nonce_field( 'gavern-post-params-nonce', 'gavern_meta_box_params_nonce' ); 
    // output for the title option
    echo '<p>';
    echo '<label for="gavern-post-params-title-value">'.__('Show title:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-title-value" id="gavern-post-params-title-value">';
    echo '<option value="Y"'.selected($value_title, 'Y', false).'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.selected($value_title, 'N', false).'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';  
    echo '</p>';
    // output for the featured image option
    echo '<p>';
    echo '<label for="gavern-post-params-image-value">'.__('Show featured image:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-image-value" id="gavern-post-params-image-value">';
    echo '<option value="Y"'.selected($value_image, 'Y', false).'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.selected($value_image, 'N', false).'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>'; 
    // output for the aside option
    echo '<p>';
    echo '<label for="gavern-post-params-aside-value">'.__('Show sidebar information:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-aside-value" id="gavern-post-params-aside-value">';
    echo '<option value="Y"'.((!$value_aside['aside'] || $value_aside['aside'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['aside'] !== FALSE && $value_aside['aside'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="gavern-post-params-date-value">'.__('Show date:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-date-value" id="gavern-post-params-date-value">';
    echo '<option value="Y"'.((!$value_aside['date'] || $value_aside['date'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['date'] !== FALSE && $value_aside['date'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="gavern-post-params-author-value">'.__('Show author:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-author-value" id="gavern-post-params-author-value">';
    echo '<option value="Y"'.((!$value_aside['author'] || $value_aside['author'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['author'] !== FALSE && $value_aside['author'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="gavern-post-params-category-value">'.__('Show category:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-category-value" id="gavern-post-params-category-value">';
    echo '<option value="Y"'.((!$value_aside['category'] || $value_aside['category'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['category'] !== FALSE && $value_aside['category'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="gavern-post-params-tags-value">'.__('Show tags:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-tags-value" id="gavern-post-params-tags-value">';
    echo '<option value="Y"'.((!$value_aside['tags'] || $value_aside['tags'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['tags'] !== FALSE && $value_aside['tags'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="gavern-post-params-comments-value">'.__('Show comments:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-comments-value" id="gavern-post-params-comments-value">';
    echo '<option value="Y"'.((!$value_aside['comments'] || $value_aside['comments'] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_aside['comments'] !== FALSE && $value_aside['comments'] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    // output for the contact page options
    echo '<p data-template="template.contact.php">';
    echo '<label for="gavern-post-params-contact-name">'.__('Show name field:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-contact-name" id="gavern-post-params-contact-name">';
    echo '<option value="Y"'.((!$value_contact || $value_contact[0] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_contact !== FALSE && $value_contact[0] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';
    echo '<p data-template="template.contact.php">';
    echo '<label for="gavern-post-params-contact-email">'.__('Show e-mail field:', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-contact-email" id="gavern-post-params-contact-email">';
    echo '<option value="Y"'.((!$value_contact || $value_contact[1] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_contact !== FALSE && $value_contact[1] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';  
    echo '<p data-template="template.contact.php">';
    echo '<label for="gavern-post-params-contact-copy">'.__('Show "send copy":', GKTPLNAME).'</label>';
    echo '<select name="gavern-post-params-contact-copy" id="gavern-post-params-contact-copy">';
    echo '<option value="Y"'.((!$value_contact || $value_contact[2] == 'Y') ? ' selected="selected"' : '').'>'.__('Enabled', GKTPLNAME).'</option>';
    echo '<option value="N"'.(($value_contact !== FALSE && $value_contact[2] == 'N') ? ' selected="selected"' : '').'>'.__('Disabled', GKTPLNAME).'</option>';
    echo '</select>';
    echo '</p>';     
} 
 
function gavern_metaboxes_save( $post_id ) {  
    // check the user permissions  
    if( !current_user_can( 'edit_post', $post_id ) ) {
    	return;
    }
    // avoid requests on the autosave 
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
    	return; 
    }  
    // check the existing of the fields and save it
    if( isset( $_POST['gavern-post-desc-value'] ) ) {
        // check the nonce
        if( !isset( $_POST['gavern_meta_box_seo_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_seo_nonce'], 'gavern-post-seo-nonce' ) ) {
        	return;
        }
        // update post meta
        update_post_meta( $post_id, 'gavern-post-desc', esc_attr( $_POST['gavern-post-desc-value'] ) );  
    }
  	//
    if( isset( $_POST['gavern-post-keywords-value'] ) ) {
    	// check the nonce
    	if( !isset( $_POST['gavern_meta_box_seo_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_seo_nonce'], 'gavern-post-seo-nonce' ) ) {
    		return;
    	}
    	// update post meta
        update_post_meta( $post_id, 'gavern-post-keywords', esc_attr( $_POST['gavern-post-keywords-value'] ) ); 
    }
    //
    if( isset( $_POST['gavern-post-params-title-value'] ) ) {
    	// check the nonce
    	if( !isset( $_POST['gavern_meta_box_params_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_params_nonce'], 'gavern-post-params-nonce' ) ) {
    		return;
    	}
    	// update post meta
        update_post_meta( $post_id, 'gavern-post-params-title', esc_attr( $_POST['gavern-post-params-title-value'] ) ); 
    }
    //
    if( isset( $_POST['gavern-post-params-aside-value'] ) ) {
    	// check the nonce
    	if( !isset( $_POST['gavern_meta_box_params_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_params_nonce'], 'gavern-post-params-nonce' ) ) {
    		return;
    	}
    	$aside_value = array(
    		'aside' => esc_attr( $_POST['gavern-post-params-aside-value'] ),
    		'date' => esc_attr( $_POST['gavern-post-params-date-value'] ),
    		'author' => esc_attr( $_POST['gavern-post-params-author-value'] ),
    		'category' => esc_attr( $_POST['gavern-post-params-category-value'] ),
    		'tags' => esc_attr( $_POST['gavern-post-params-tags-value'] ),
    		'comments' => esc_attr( $_POST['gavern-post-params-comments-value'] )
    	);
    	// update post meta
        update_post_meta( $post_id, 'gavern-post-params-aside', serialize($aside_value) ); 
    }
    //
    if( isset( $_POST['gavern-post-params-image-value'] ) ) {
    	// check the nonce
    	if( !isset( $_POST['gavern_meta_box_params_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_params_nonce'], 'gavern-post-params-nonce' ) ) {
    		return;
    	}
    	// update post meta
        update_post_meta( $post_id, 'gavern-post-params-image', esc_attr( $_POST['gavern-post-params-image-value'] ) ); 
    }
    //
    if( isset( $_POST['gavern-post-params-contact-name'] ) ) {
    	// check the nonce
    	if( !isset( $_POST['gavern_meta_box_params_nonce'] ) || !wp_verify_nonce( $_POST['gavern_meta_box_params_nonce'], 'gavern-post-params-nonce' ) ) {
    		return;
    	}
    	// update post meta
    	$contact_value = esc_attr( $_POST['gavern-post-params-contact-name'] ) . ',' . esc_attr( $_POST['gavern-post-params-contact-email'] ) . ',' . esc_attr( $_POST['gavern-post-params-contact-copy'] );
    	$templates_value = array('contact' => $contact_value);
        update_post_meta( $post_id, 'gavern-post-params-templates', serialize($templates_value) ); 
    }
} 

/**
 *
 * Code to create Featured Video metabox
 *
 **/

function gavern_add_featured_video() {
    global $tpl;
    if(get_option($tpl->name . "_featured_video", 'Y') == 'Y') {
        add_meta_box( 'gavern_featured_video', __( 'Featured Video', GKTPLNAME ), 'gavern_add_featured_video_metabox', 'post', 'side' );
        add_meta_box( 'gavern_featured_video', __( 'Featured Video', GKTPLNAME ), 'gavern_add_featured_video_metabox', 'page', 'side' );
    }
}

function gavern_add_featured_video_metabox() {
    global $post;

    $featured_video = get_post_meta($post->ID, '_gavern-featured-video', true);
    
    echo '<div>';
    echo '<label>'.__('Video Embed Code', GKTPLNAME).'</label>';
    echo '<textarea name="gavern_featured_video" class="widefat">'.$featured_video.'</textarea>';
    echo '<input type="hidden" name="gavern_featured_video_nonce" id="gavern_featured_video_nonce" value="'.wp_create_nonce(plugin_basename(__FILE__)).'" />';
    echo '</div>';
}

function gavern_save_featured_video(){
    global $post;
	// check nonce
    if(!isset($_POST['gavern_featured_video_nonce']) || !wp_verify_nonce($_POST['gavern_featured_video_nonce'], plugin_basename(__FILE__))) {
        return is_object($post) ? $post->ID : $post;
	}
	// autosave
	if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return is_object($post) ? $post->ID : $post;
	}
	// user permissions
	if(
		($_POST['post_type'] == 'page' && !current_user_can('edit_page', $post->ID)) ||
		($_POST['post_type'] == 'post' && !current_user_can('edit_post', $post->ID))
	) {
		return $post->ID;
	}
	// if the value exists
    if(isset($_POST['gavern_featured_video'])) {
	    $featured_video = $_POST['gavern_featured_video'];
	    
	    if($featured_video != '') {
	    	delete_post_meta($post->ID, '_gavern-featured-video');
	    	add_post_meta($post->ID, '_gavern-featured-video', $featured_video);
	    } else {
	    	delete_post_meta($post->ID, '_gavern-featured-video');
	    }
    }
    
	return true;
}


add_action( 'save_post',  'gavern_save_featured_video' );
add_action( 'admin_menu', 'gavern_add_featured_video' );

/**
 *
 * Code to create widget showing manager
 *
 **/

// define an additional operation when save the widget
add_filter( 'widget_update_callback', 'gavern_widget_update', 10, 4);

// definition of the additional operation
function gavern_widget_update($instance, $new_instance, $old_instance, $widget) {	
	global $tpl;
	// check if param was set
	if ( isset( $_POST[$tpl->name . '_widget_rules_' . $widget->id] ) ) {	
		// get option and style value
		$options_type = get_option($tpl->name . '_widget_rules_type');
		$options = get_option($tpl->name . '_widget_rules');
		$styles = get_option($tpl->name . '_widget_style');
		$styles_css = get_option($tpl->name . '_widget_style_css');
		$responsive = get_option($tpl->name . '_widget_responsive');
		$users = get_option($tpl->name . '_widget_users');
		// if this option is set at first time
		if(!is_array($options_type) ) {
			$options_type = array();
		}
		// if this option is set at first time
		if(!is_array($options) ) {
			$options = array();
		}
		// if this styles is set at first time
		if( !is_array($styles) ) {
			$styles = array();
		}
		// if this styles is set at first time
		if( !is_array($styles_css) ) {
			$styles_css = array();
		}
		// if this responsive is set at first time
		if( !is_array($responsive) ) {
			$responsive = array();
		}
		// if this users is set at first time
		if( !is_array($users) ) {
			$users = array();
		}
		// set the new key in the array
		$options_type[$widget->id] = $_POST[$tpl->name . '_widget_rules_type_' . $widget->id];
		$options[$widget->id] = $_POST[$tpl->name . '_widget_rules_' . $widget->id];
		$styles[$widget->id] = $_POST[$tpl->name . '_widget_style_' . $widget->id];
		$styles_css[$widget->id] = $_POST[$tpl->name . '_widget_style_css_' . $widget->id];
		$responsive[$widget->id] = $_POST[$tpl->name . '_widget_responsive_' . $widget->id];
		$users[$widget->id] = $_POST[$tpl->name . '_widget_users_' . $widget->id];
		
		//
		// Clean up the variables
		//
		
		// get all widgets names
		$all_widgets = array();
		$all_widgets_assoc = get_option('sidebars_widgets'); 
		// iterate throug the sidebar widgets settings to get all active widgets names
		foreach($all_widgets_assoc as $sidebar_name => $sidebar) {
			// remember about wp_inactive_widgets and array_version fields!
			if($sidebar_name != 'wp_inactive_widgets' && is_array($sidebar) && count($sidebar) > 0) {
				foreach($sidebar as $widget_name) {
					array_push($all_widgets, $widget_name);
				}
			}
		}
		// get the widget names from the exisitng settings
		$widget_names = array_keys($options_type);
		// check for the unexisting widgets
        foreach($widget_names as $widget_name) {
            // if widget doesn't exist - remove it from the options
            if(in_array($widget_name, $all_widgets) !== TRUE) {
                if(isset($options_type) && is_array($options_type) && isset($options_type[$widget_name])) {
                    unset($options_type[$widget_name]);
                }

                if(isset($options) && is_array($options) && isset($options[$widget_name])) {
                    unset($options[$widget_name]);
                }

                if(isset($styles) && is_array($styles) && isset($styles[$widget_name])) {
                    unset($styles[$widget_name]);
                }

                if(isset($styles_css) && is_array($styles_css) && isset($styles_css[$widget_name])) {
                    unset($styles_css[$widget_name]);
                }

                if(isset($responsive) && is_array($responsive) && isset($responsive[$widget_name])) {
                    unset($responsive[$widget_name]);
                }

                if(isset($users) && is_array($users) && isset($users[$widget_name])) {
                    unset($users[$widget_name]);
                }
            }
        }
		// update the settings
		update_option($tpl->name . '_widget_rules_type', $options_type);
		update_option($tpl->name . '_widget_rules', $options);
		update_option($tpl->name . '_widget_style', $styles);
		update_option($tpl->name . '_widget_style_css', $styles_css);
		update_option($tpl->name . '_widget_responsive', $responsive);
		update_option($tpl->name . '_widget_users', $users);
	}	
	// return the widget instance
	return $instance;
}

// function to add the widget control 
function gavern_widget_control() {	
	// get the access to the registered widget controls
	global $wp_registered_widget_controls;
	global $tpl;
	
	// check if the widget rules are enabled
	if(get_option($tpl->name . '_widget_rules_state') == 'Y') {
		// get the widget parameters
		$params = func_get_args();
		// find the widget ID
		$id = $params[0]['widget_id'];
		$unique_id = $id . '-' . rand(10000000, 99999999);
		// get option value
		$options_type = get_option($tpl->name . '_widget_rules_type');
		$options = get_option($tpl->name . '_widget_rules');
		$styles = get_option($tpl->name . '_widget_style');
		$styles_css = get_option($tpl->name . '_widget_style_css');
		$responsive = get_option($tpl->name . '_widget_responsive');
		$users = get_option($tpl->name . '_widget_users');
		// if this option is set at first time
		if( !is_array($options_type) ) {
			$options_type = array();
		}
		// if this option is set at first time
		if( !is_array($options) ) {
			$options = array();
		}
		// if this styles is set at first time
		if( !is_array($styles) ) {
			$styles = array();
		}
		// if this responsive is set at first time
		if( !is_array($responsive) ) {
			$responsive = array();
		}
		// if this users is set at first time
		if( !is_array($users) ) {
			$users = array();
		}
		// get the widget form callback
		$callback = $wp_registered_widget_controls[$id]['callback_redir'];
		// if the callbac exist - run it with the widget parameters
		if (is_callable($callback)) {
			call_user_func_array($callback, $params);
		}
		// value of the option
		$value_type = !empty($options_type[$id]) ? htmlspecialchars(stripslashes($options_type[$id]),ENT_QUOTES) : '';
		$value = !empty($options[$id]) ? htmlspecialchars(stripslashes($options[$id]),ENT_QUOTES) : '';	
		$style = !empty($styles[$id]) ? htmlspecialchars(stripslashes($styles[$id]),ENT_QUOTES) : '';
		$style_css = !empty($styles_css[$id]) ? htmlspecialchars(stripslashes($styles_css[$id]),ENT_QUOTES) : '';	
		$responsiveMode = !empty($responsive[$id]) ? htmlspecialchars(stripslashes($responsive[$id]),ENT_QUOTES) : '';	
		$usersMode = !empty($users[$id]) ? htmlspecialchars(stripslashes($users[$id]),ENT_QUOTES) : '';	
		// 
		echo '
		<a class="gk_widget_rules_btn button">'.__('Widget rules', GKTPLNAME).'</a>
		<div class="gk_widget_rules_wrapper'.((isset($_COOKIE['gk_last_opened_widget_rules_wrap']) && $_COOKIE['gk_last_opened_widget_rules_wrap'] == 'gk_widget_rules_form_'.$id) ? ' active' : '').'" data-id="gk_widget_rules_form_'.$id.'">
			<p>
				<label for="' . $tpl->name . '_widget_rules_'.$id.'">'.__('Visible at: ', GKTPLNAME).'</label>
				<select name="' . $tpl->name . '_widget_rules_type_'.$id.'" id="' . $tpl->name . '_widget_rules_type_'.$id.'" class="gk_widget_rules_select">
					<option value="all"'.(($value_type != "include" && $value_type != 'exclude') ? " selected=\"selected\"":"").'>'.__('All pages', GKTPLNAME).'</option>
					<option value="exclude"'.selected($value_type, "exclude", false).'>'.__('All pages except:', GKTPLNAME).'</option>
					<option value="include"'.selected($value_type, "include", false).'>'.__('No pages except:', GKTPLNAME).'</option>
				</select>
			</p>
			<fieldset class="gk_widget_rules_form" id="gk_widget_rules_form_'.$unique_id.'" data-id="gk_widget_rules_form_'.$id.'">
				<legend>'.__('Select page to add', GKTPLNAME).'</legend>
				 <select class="gk_widget_rules_form_select">
				 	<option value="homepage">'.__('Homepage', GKTPLNAME).'</option>
				 	<option value="page:">'.__('Page', GKTPLNAME).'</option>
				 	<option value="post:">'.__('Post', GKTPLNAME).'</option>
				 	<option value="category:">'.__('Category', GKTPLNAME).'</option>
				 	<option value="category_descendant:">'.__('Category with descendants', GKTPLNAME).'</option>
				 	<option value="tag:">'.__('Tag', GKTPLNAME).'</option>
				 	<option value="archive">'.__('Archive', GKTPLNAME).'</option>
				 	<option value="author:">'.__('Author', GKTPLNAME).'</option>
				 	<option value="template:">'.__('Page Template', GKTPLNAME).'</option>
				 	<option value="taxonomy:">'.__('Taxonomy', GKTPLNAME).'</option>
				 	<option value="posttype:">'.__('Post type', GKTPLNAME).'</option>
				 	<option value="search">'.__('Search page', GKTPLNAME).'</option>
				 	<option value="page404">'.__('404 page', GKTPLNAME).'</option>
				 </select>
				 <p><label>'.__('Page ID/Title/slug:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_page" /></label></p>
				 <p><label>'.__('Post ID/Title/slug:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_post" /></label></p>
				 <p><label>'.__('Category ID/Name/slug:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_category" /></label></p>
				 <p><label>'.__('Category ID:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_category_descendant" /></label></p>
				 <p><label>'.__('Tag ID/Name:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_tag" /></label></p>
				 <p><label>'.__('Author:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_author" /></label></p>
				 <p><label>'.__('Template:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_template" /></label></p>
				 <p><label>'.__('Taxonomy:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_taxonomy" /></label></p>
				 <p><label>'.__('Taxonomy term:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_taxonomy_term" /></label></p>
				 <p><label>'.__('Post type:', GKTPLNAME).'<input type="text" class="gk_widget_rules_form_input_posttype" /></label></p>
				 <p><button class="gk_widget_rules_btn button-secondary">'.__('Add page', GKTPLNAME).'</button></p>
				 <input type="text" name="' . $tpl->name . '_widget_rules_'.$id.'"  id="' . $tpl->name . '_widget_rules_'.$id.'" value="'.$value.'" class="gk_widget_rules_output" />
				 <fieldset class="gk_widget_rules_pages">
				 	<legend>'.__('Selected pages', GKTPLNAME).'</legend>
				 	<span class="gk_widget_rules_nopages">'.__('No pages', GKTPLNAME).'</span>
				 	<div></div>
				 </fieldset>
			</fieldset>
			<script type="text/javascript">gk_widget_control_init(\'#gk_widget_rules_form_'.$unique_id.'\');</script>';
		// create the list of suffixes
		gavern_widget_control_styles_list($params[0]['widget_id'], $id, $style, $responsiveMode, $usersMode, $style_css);
	} else {
		// get the widget parameters
		$params = func_get_args();
		// find the widget ID
		$id = $params[0]['widget_id'];
		// get the widget form callback
		$callback = $wp_registered_widget_controls[$id]['callback_redir'];
		// if the callbac exist - run it with the widget parameters
		if (is_callable($callback)) {
			call_user_func_array($callback, $params);
		}
	}
}

add_action( 'sidebar_admin_setup', 'gavern_add_widget_control'); 

function gavern_add_widget_control() {	
	global $tpl;
	global $wp_registered_widgets; 
	global $wp_registered_widget_controls;
	// get option value
	$options_type = get_option($tpl->name . '_widget_rules_type');
	$options = get_option($tpl->name . '_widget_rules');
	$styles = get_option($tpl->name . '_widget_style');
	$styles_css = get_option($tpl->name . '_widget_style_css');
	$responsive = get_option($tpl->name . '_widget_responsive');
	$users = get_option($tpl->name . '_widget_users');
	// if this option is set at first time
	if( !is_array($options) ) {
		$options = array();
	}
	// if this styles is set at first time
	if( !is_array($styles) ) {
		$styles = array();
	}
	// if this style CSS is set at first time
	if( !is_array($styles_css) ) {
		$styles_css = array();
	}
	// if this responsive is set at first time
	if( !is_array($responsive) ) {
		$responsive = array();
	}
	// if this users is set at first time
	if( !is_array($users) ) {
		$users = array();
	}
	// AJAX updates
	if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {	
		foreach ( (array) $_POST['widget-id'] as $widget_number => $widget_id ) {
			// save widget rules type
			if (isset($_POST[$tpl->name . '_widget_rules_type_' . $widget_id])) {
				$options_type[$widget_id] = $_POST[$tpl->name . '_widget_rules_type_' . $widget_id];
			}
			// save widget rules
			if (isset($_POST[$tpl->name . '_widget_rules_' . $widget_id])) {
				$options[$widget_id] = $_POST[$tpl->name . '_widget_rules_' . $widget_id];
			}
			// save widget style
			if (isset($_POST[$tpl->name . '_widget_style_' . $widget_id])) {
				$styles[$widget_id] = $_POST[$tpl->name . '_widget_style_' . $widget_id];
			}
			// save widget style CSS
			if (isset($_POST[$tpl->name . '_widget_style_css_' . $widget_id])) {
				$styles_css[$widget_id] = $_POST[$tpl->name . '_widget_style_css_' . $widget_id];
			}
			// save widget responsive
			if (isset($_POST[$tpl->name . '_widget_responsive_' . $widget_id])) {
				$responsive[$widget_id] = $_POST[$tpl->name . '_widget_responsive_' . $widget_id];
			}
			// save widget users
			if (isset($_POST[$tpl->name . '_widget_users_' . $widget_id])) {
				$users[$widget_id] = $_POST[$tpl->name . '_widget_users_' . $widget_id];
			}
		}
	}
	// save the widget id
	foreach ( $wp_registered_widgets as $id => $widget ) {	
		// save the widget id		
		$wp_registered_widget_controls[$id]['params'][0]['widget_id'] = $id;
		// do the redirection
		$wp_registered_widget_controls[$id]['callback_redir'] = $wp_registered_widget_controls[$id]['callback'];
		$wp_registered_widget_controls[$id]['callback'] = 'gavern_widget_control';		
	}
}

function gavern_widget_control_styles_list($widget_name, $id, $value1, $value2, $value3, $value4 = '') {
	// getting access to the template global object. 
	global $tpl;
	// clear the widget name - get the name without number at end
	$widget_name = preg_replace('/\-[0-9]+$/mi', '', $widget_name);
	// load and parse widgets JSON file.
	$json_data = $tpl->get_json('config','widgets.styles');
	// prepare an array of options
	$items = array('<option value="" selected="selected">'.__('None', GKTPLNAME).'</option>');
	$for_only_array = array();
	$exclude_array = array();
	// iterate through all styles in the file
	foreach ($json_data as $style) {
		// flag
		$add_the_item = true;
		// check the for_only tag
		if(isset($style->for_only)) {
			$for_only_array = explode(',', $style->for_only);
			if(array_search($widget_name, $for_only_array) === FALSE) {
				$add_the_item = false;
			}
		// check the exclude tag
		} else if(isset($style->exclude)) {
			$exclude_array = explode(',', $style->exclude);
			
			if(array_search($widget_name, $exclude_array) !== FALSE) {
				$add_the_item = false;
			}
		} 
		// check the flag state
		if($add_the_item) {
			// add the item if the module isn't excluded
			array_push($items, '<option value="'.$style->css_class.'"'.selected($style->css_class, $value1, false).'>'.$style->name.'</option>');
		}
	}
	// check if the items array is blank - the prepare a basic field
	if(count($items) == 1) {
		$items = array('<option value="" selected="selected">'.__('No styles available', GKTPLNAME).'</option>');
	}
	// add the last option
	array_push($items, '<option value="gkcustom"'.selected($value1, 'gkcustom', false).'>'.__('Custom CSS class', GKTPLNAME).'</option>');
	// output the control
	echo '<div>';
	echo '<p><label for="' . $tpl->name . '_widget_style_'.$id.'">'.__('Widget style: ', GKTPLNAME).'<select name="' . $tpl->name . '_widget_style_'.$id.'"  id="' . $tpl->name . '_widget_style_'.$id.'" class="gk_widget_rules_select_styles">';
	foreach($items as $item) echo $item;
	echo '</select></label></p>';
	//
	echo '<p'.(($value1 != 'gkcustom') ? ' class="gk-unvisible"' : '').'><label for="' . $tpl->name . '_widget_style_css_'.$id.'">'.__('Custom CSS class: ', GKTPLNAME).'<input type="text" name="' . $tpl->name . '_widget_style_css_'.$id.'"  id="' . $tpl->name . '_widget_style_class_'.$id.'" value="'.$value4.'" /></label></p>';
	// output the responsive select
	$items = array(
		'<option value="all"'.((!$value2 || $value2 == 'all') ? ' selected="selected"' : '').'>'.__('All devices', GKTPLNAME).'</option>',
		'<option value="onlyDesktop"'.selected($value2, 'onlyDesktop', false).'>'.__('Desktop', GKTPLNAME).'</option>',
		'<option value="onlyTablets"'.selected($value2, 'onlyTablets', false).'>'.__('Tablets', GKTPLNAME).'</option>',
		'<option value="onlySmartphones"'.selected($value2, 'onlySmartphones', false).'>'.__('Smartphones', GKTPLNAME).'</option>',
		'<option value="onlyTabltetsAndSmartphones"'.selected($value2, 'onlyTabltetsAndSmartphones', false).'>'.__('Tablet/Smartphones', GKTPLNAME).'</option>'
	);
	//
	echo '<p><label for="' . $tpl->name . '_widget_responsive_'.$id.'">'.__('Visible on: ', GKTPLNAME).'<select name="' . $tpl->name . '_widget_responsive_'.$id.'"  id="' . $tpl->name . '_widget_responsive_'.$id.'">';
	//
	foreach($items as $item) {
		echo $item;
	}
	//
	echo '</select></label></p>';
	// output the user groups select
	$items = array(
		'<option value="all"'.(($value3 == null || !$value3 || $value3 == 'all') ? ' selected="selected"' : '').'>'.__('All users', GKTPLNAME).'</option>',
		'<option value="guests"'.selected($value3, 'guests', false).'>'.__('Only guests', GKTPLNAME).'</option>',
		'<option value="registered"'.selected($value3, 'registered', false).'>'.__('Only registered users', GKTPLNAME).'</option>',
		'<option value="administrator"'.selected($value3, 'administrator', false).'>'.__('Only administrator', GKTPLNAME).'</option>'
	);
	//
	echo '<p><label for="' . $tpl->name . '_widget_users_'.$id.'">'.__('Visible for: ', GKTPLNAME).'<select name="' . $tpl->name . '_widget_users_'.$id.'"  id="' . $tpl->name . '_widget_users_'.$id.'">';
	//
	foreach($items as $item) {
		echo $item;
	}
	//
	echo '</select></label></p></div>';
	//
	if(get_option($tpl->name . '_widget_rules_state') == 'Y') {
		echo '</div>';
	}
	//
	echo '<hr />';
}
 
// Add the Meta Box
function gavern_add_og_meta_box() {
    add_meta_box(
		'gavern_og_meta_box',
		'Open Graph metatags',
		'gavern_show_og_meta_box',
		'post',
		'normal',
		'high'
	);
	
	add_meta_box(
		'gavern_og_meta_box',
		'Open Graph metatags',
		'gavern_show_og_meta_box',
		'page',
		'normal',
		'high'
	);
}
// check if the Open Graph is enabled
if(get_option($tpl->name . '_opengraph_use_opengraph') == 'Y') {
	add_action('add_meta_boxes', 'gavern_add_og_meta_box');
}

// The Callback
function gavern_show_og_meta_box() {
	global $tpl, $post;
	// load custom meta fields
	$custom_meta_fields = $tpl->get_json('config', 'opengraph');
	// Use nonce for verification
	echo '<input type="hidden" name="custom_meta_box_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';
	// Begin the field table and loop
	echo '<table class="form-table">';
	foreach ($custom_meta_fields as $field) {
		// get value of this field if it exists for this post
		$meta = get_post_meta($post->ID, $field->id, true);
		// begin a table row with
		echo '<tr>
				<th><label for="'.$field->id.'">'.$field->label.'</label></th>
				<td>';
				switch($field->type) {
					// case items will go here
					// text
					case 'text':
						echo '<input type="text" name="'.$field->id.'" id="'.$field->id.'" value="'.$meta.'" size="30" />
							<br /><span class="description">'.$field->desc.'</span>';
					break;
					
					// textarea
					case 'textarea':
						echo '<textarea name="'.$field->id.'" id="'.$field->id.'" cols="60" rows="4">'.$meta.'</textarea>
							<br /><span class="description">'.$field->desc.'</span>';
					break;
					
					// image
					case 'image':
						$image = 'none';
						if (get_option($tpl->name . '_og_default_image', '') != '')  {
							$image = get_option($tpl->name . '_og_default_image'); 
						}
						echo '<span class="gavern_opengraph_default_image" style="display:none">'.$image.'</span>';
						if ($meta) { 
							$image = wp_get_attachment_image_src($meta, 'medium');	
							$image = $image[0];
						}
						echo	'<input name="'.$field->id.'" type="hidden" class="gavern_opengraph_upload_image" value="'.$meta.'" />
									<img src="'.$image.'" class="gavern_opengraph_preview_image" alt="" /><br />
										<input class="gavern_opengraph_upload_image_button button" type="button" value="Choose Image" />
										<small><a href="#" class="gavern_opengraph_clear_image">Remove Image</a></small>
										<br clear="all" /><span class="description">'.$field->desc.'';
					break;
				} //end switch
		echo '</td></tr>';
	} // end foreach
	echo '</table>'; // end table
}
 
// Save the Data
function gavern_save_custom_meta($post_id) {
    global $tpl;
    
    if(isset($post_id)) {
		// load custom meta fields
		$custom_meta_fields = $tpl->get_json('config', 'opengraph');
		// verify nonce
		if (isset($_POST['custom_meta_box_nonce']) && !wp_verify_nonce($_POST['custom_meta_box_nonce'], basename(__FILE__)))
			return $post_id;
		// check autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
			return $post_id;
		// check permissions
		if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id))
				return $post_id;
			} elseif (!current_user_can('edit_post', $post_id)) {
				return $post_id;
		}
	
		// loop through fields and save the data
		foreach ($custom_meta_fields as $field) {
			$old = get_post_meta($post_id, $field->id, true);
			
			if(isset($_POST[$field->id])) {
				$new = $_POST[$field->id];
				if ($new && $new != $old) {
					update_post_meta($post_id, $field->id, $new);
				} elseif ('' == $new && $old) {
					delete_post_meta($post_id, $field->id, $old);
				}
			}
		} // end foreach
	}
}

add_action('save_post', 'gavern_save_custom_meta');  


// Add the Meta Box for Twitter cards
function gavern_add_twitter_meta_box() {
    add_meta_box(
		'gavern_twitter_meta_box',
		'Twitter Cards metatags',
		'gavern_show_twitter_meta_box',
		'post',
		'normal',
		'high'
	);
	
	add_meta_box(
		'gavern_twitter_meta_box',
		'Twitter Cards metatags',
		'gavern_show_twitter_meta_box',
		'page',
		'normal',
		'high'
	);
}

if(get_option($tpl->name . '_twitter_cards') == 'Y') {
	add_action('add_meta_boxes', 'gavern_add_twitter_meta_box');
}

// The Callback for Twiter metabox
function gavern_show_twitter_meta_box() {
	global $tpl, $post;
	// load custom meta fields
	$custom_meta_fields = $tpl->get_json('config', 'twitter');
	// Use nonce for verification
	echo '<input type="hidden" name="custom_meta_box_nonce2" value="'.wp_create_nonce(basename(__FILE__)).'" />';
	// Begin the field table and loop
	echo '<table class="form-table">';
	foreach ($custom_meta_fields as $field) {
		// get value of this field if it exists for this post
		$meta = get_post_meta($post->ID, $field->id, true);
		
		// begin a table row with
		echo '<tr>
				<th><label for="'.$field->id.'">'.$field->label.'</label></th>
				<td>';
				switch($field->type) {
					// case items will go here
					// text
					case 'text':
						echo '<input type="text" name="'.$field->id.'" id="'.$field->id.'" value="'.$meta.'" size="30" />
							<br /><span class="description">'.$field->desc.'</span>';
					break;
					
					// textarea
					case 'textarea':
						echo '<textarea name="'.$field->id.'" id="'.$field->id.'" cols="60" rows="4">'.$meta.'</textarea>
							<br /><span class="description">'.$field->desc.'</span>';
					break;
					
					// image
					case 'image':
						$image = 'none';
						if (get_option($tpl->name . '_og_default_image', '') != '')  {
							$image = get_option($tpl->name . '_og_default_image'); 
						}
						echo '<span class="gavern_opengraph_default_image" style="display:none">'.$image.'</span>';
						if ($meta) { 
							$image = wp_get_attachment_image_src($meta, 'medium');	
							$image = $image[0];
						}
						echo	'<input name="'.$field->id.'" type="hidden" class="gavern_opengraph_upload_image" value="'.$meta.'" />
									<img src="'.$image.'" class="gavern_opengraph_preview_image" alt="" /><br />
										<input class="gavern_opengraph_upload_image_button button" type="button" value="Choose Image" />
										<small><a href="#" class="gavern_opengraph_clear_image">Remove Image</a></small>
										<br clear="all" /><span class="description">'.$field->desc.'';
					break;
				} //end switch
		echo '</td></tr>';
	} // end foreach
	echo '</table>'; // end table
}

function gavern_save_custom__twitter_meta($post_id) {
    global $tpl;
    
    if(isset($post_id)) {
		// load custom meta fields
		$custom_meta_fields = $tpl->get_json('config', 'twitter');
		// verify nonce
		if (isset($_POST['custom_meta_box_nonce']) && !wp_verify_nonce($_POST['custom_meta_box_nonce'], basename(__FILE__)))
			return $post_id;
		// check autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
			return $post_id;
		// check permissions
		if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id))
				return $post_id;
			} elseif (!current_user_can('edit_post', $post_id)) {
				return $post_id;
		}
	
		// loop through fields and save the data
		foreach ($custom_meta_fields as $field) {
			$old = get_post_meta($post_id, $field->id, true);
			
			if(isset($_POST[$field->id])) {
				$new = $_POST[$field->id];
				if ($new && $new != $old) {
					update_post_meta($post_id, $field->id, $new);
				} elseif ('' == $new && $old) {
					delete_post_meta($post_id, $field->id, $old);
				}
			}
		} // end foreach
	}
}

add_action('save_post', 'gavern_save_custom__twitter_meta');


/**
 *
 * Code used to implement the OpenSearch
 *
 **/

// function used to put in the page header the link to the opensearch XML description file
function gavern_opensearch_head() {
	echo '<link href="'.get_bloginfo('url').'/?opensearch_description=1" title="'.get_bloginfo('name').'" rel="search" type="application/opensearchdescription+xml" />';
}

// function used to add the opensearch_description variable
function gavern_opensearch_query_vars($vars) {
	$vars[] = 'opensearch_description';
	return $vars;
}

// function used to generate the openserch XML description output 
function gavern_opensearch() {
	// access to the wp_query variable
	global $wp_query;
	// check if there was an variable opensearch_description in the query vars
	if (!empty($wp_query->query_vars['opensearch_description']) ) {
		// if yes - return the XML with OpenSearch description
		header('Content-Type: text/xml');
		// the XML content
		echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
		echo "<OpenSearchDescription xmlns=\"http://a9.com/-/spec/opensearch/1.1/\">\n";
		echo "\t<ShortName>".get_bloginfo('name')."</ShortName>\n";
		echo "\t<LongName>".get_bloginfo('name')."</LongName>\n";
		echo "\t<Description>Search &quot;".get_bloginfo('name')."&quot;</Description>\n";
		echo "\t<Image width=\"16\" height=\"16\" type=\"image/x-icon\">".gavern_file_uri('favicon.ico')."</Image>\n";
		echo "\t<Contact>".get_bloginfo('admin_email')."</Contact>\n";
		echo "\t<Url type=\"text/html\" template=\"".get_bloginfo('url')."/?s={searchTerms}\"/>\n";
		echo "\t<Url type=\"application/atom+xml\" template=\"".get_bloginfo('url')."/?feed=atom&amp;s={searchTerms}\"/>\n";
		echo "\t<Url type=\"application/rss+xml\" template=\"".get_bloginfo('url')."/?feed=rss2&amp;s={searchTerms}\"/>\n";
		echo "\t<Language>".get_bloginfo('language')."</Language>\n";
		echo "\t<OutputEncoding>".get_bloginfo('charset')."</OutputEncoding>\n";
		echo "\t<InputEncoding>".get_bloginfo('charset')."</InputEncoding>\n";
		echo "</OpenSearchDescription>";
		exit;
	}
	// if not just end the function
	return;
}

// add necessary actions and filters if OpenSearch is enabled
if(get_option($tpl->name . "_opensearch_use_opensearch", "Y") == "Y") {
	add_action('wp_head', 'gavern_opensearch_head');
	add_action('template_redirect', 'gavern_opensearch');
	add_filter('query_vars', 'gavern_opensearch_query_vars');
}

/**
 * Tests if any of a post's assigned categories are descendants of target categories
 *
 * @param int|array $cats The target categories. Integer ID or array of integer IDs
 * @param int|object $_post The post. Omit to test the current post in the Loop or main query
 * @return bool True if at least 1 of the post's categories is a descendant of any of the target categories
 * @see get_term_by() You can get a category by name or slug, then pass ID to this function
 * @uses get_term_children() Passes $cats
 * @uses in_category() Passes $_post (can be empty)
 * @version 2.7
 * @link http://codex.wordpress.org/Function_Reference/in_category#Testing_if_a_post_is_in_a_descendant_category
 */
if ( ! function_exists( 'post_is_in_descendant_category' ) ) {
	function post_is_in_descendant_category( $cats, $_post = null ) {
		foreach ( (array) $cats as $cat ) {
			// get_term_children() accepts integer ID only
			$descendants = get_term_children( (int) $cat, 'category' );
			if ( $descendants && in_category( $descendants, $_post ) )
				return true;
		}
		return false;
	}
}

/**
 *
 * Code used to implement parsing shortcodes and emoticons in the text widgets
 *
 **/

if(get_option($tpl->name . "_shortcodes_widget_state", "Y") == "Y") {
	add_filter('widget_text', 'do_shortcode');
}
	
if(get_option($tpl->name . "_emoticons_widget_state", "Y") == "Y") {
	add_filter('widget_text', 'convert_smilies');
}

// EOF