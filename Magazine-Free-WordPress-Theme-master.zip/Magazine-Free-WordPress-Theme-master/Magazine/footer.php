<?php

// This file was added especially for the wp-signup.php and wp-activate.php files :-)

gk_load('after');
gk_load('footer');

// EOF