/**
 *
 * -------------------------------------------
 * Script for the contact page
 * -------------------------------------------
 *
 **/
 
 
jQuery(document).ready(function(){
	jQuery("#contactForm").validate();
});